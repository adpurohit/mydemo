<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'task/index';
$route['account_registration_db'] = 'task/account_registration_db';

$route['login'] = 'task/login';
$route['login_db'] = 'task/login_db';

$route['dashboard'] = 'task/dashboard';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
