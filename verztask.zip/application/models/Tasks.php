<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tasks extends CI_Model {

	public function account_registration_db() {
		$fullname = isset($_POST['fullname']) ? $_POST['fullname'] : "";
		$email = isset($_POST['email']) ? $_POST['email'] : "";
		$profile = $_FILES['profile']['name'];
		$mobile = isset($_POST['mobile']) ? $_POST['mobile'] : "";
		$password = isset($_POST['password']) ? $_POST['password'] : "";
		$created_at = date("Y-m-d H:i:s");
//print_r($_FILES);
		$sel_query = "select email from account where email = ?";
		$sel_query = $this->db->query($sel_query, array($email));
		if($sel_query->num_rows()<1) {
			$ins_query = "insert into account(fullname, email, mobile, profile, password, created_at) values(?, ?, ?, ?, ?, ?)";
			$ins_query = $this->db->query($ins_query, array($fullname, $email, $mobile, $profile, $password, $created_at));
			if($ins_query===true) {
				return redirect('login');
			}
		}
		else {
			return "email_exist";
		}
	}

	public function login_db() {
		$email = isset($_POST['email']) ? $_POST['email'] : "";
		$password = isset($_POST['password']) ? $_POST['password'] : "";

		$sel_query = "select email, password from account where email= ? and password= ?";
		$sel_query = $this->db->query($sel_query, array($email, $password));
		if($sel_query->num_rows()>0) {
			$row = $sel_query->row();
			$login_credentials = array(
				'id'		=> $row->id,
		        'email'     => $row->email,
		        'logged_in' => TRUE
			);

			$this->session->set_userdata('login_credentials', $login_credentials);
			redirect('dashboard');
		}
		else {
			return "invalid_credentials";
		}
	}

	public function get_data() {
		$sel_query = "select * from account";
		$sel_query = $this->db->query($sel_query);
		return $sel_query->result();
	}
}