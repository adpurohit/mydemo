<div class="container">
    <div class="row">
        <h1>Dasboard</h1>

        <div class="col-md-12 table-responsive">
            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Profile</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $i = 1;
                        if(count($user_data)) {
                        foreach($user_data as $user) {
                    ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><img src="<?php echo base_url('assets/images/'.$user->profile); ?>" width="50px"></td>
                        <td><?php echo isset($user->fullname) ? $user->fullname : "-"; ?></td>
                        <td><?php echo isset($user->email) ? $user->email : "-"; ?></td>
                        <td><?php echo isset($user->mobile) ? $user->mobile : "-"; ?></td>
                        <td><?php echo isset($user->created_at) ? date("d-m-y h:i A", strtotime($user->created_at)) : "-"; ?></td>
                    </tr>
                    <?php $i++;}}else { ?>
                    <tr>
                        <td colspan="6" class="text-center">No data found</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
<script type="text/javascript">
    $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>

