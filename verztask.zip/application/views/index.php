<div class="container">
    <div class="row">
        <h1>Account Registration</h1>
        <div class="col-sm-4">
            <form id="account_registration_db" method="POST" action="<?php echo site_url('account_registration_db'); ?>" enctype="multipart/form-data">
            <div class="form-group">
                <label>Profile</label>
                <input type="file" name="profile" class="form-control">
                <?php echo isset($error) ? $error : ""; ?>
            </div>
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="fullname" placeholder="Full name" class="form-control" value="<?php echo isset($_POST['fullname']) ? $_POST['fullname'] : ""; ?>">
                <?php echo form_error('fullname', '<div class="text-danger">', '</div>'); ?>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="text" name="email" placeholder="Email" class="form-control" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ""; ?>">
                <?php echo form_error('email', '<div class="text-danger">', '</div>'); ?>
                <?php echo isset($email_error) ? $email_error : ""; ?>
            </div>
            <div class="form-group">
                <label>Mobile</label>
                <input type="text" name="mobile" placeholder="Mobile" class="form-control" value="<?php echo isset($_POST['mobile']) ? $_POST['mobile'] : ""; ?>">
                <?php echo form_error('mobile', '<div class="text-danger">', '</div>'); ?>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Password" class="form-control" value="<?php echo isset($_POST['password']) ? $_POST['password'] : ""; ?>">
                <?php echo form_error('password', '<div class="text-danger">', '</div>'); ?>
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="cpassword" placeholder="Confirm Password" class="form-control" value="<?php echo isset($_POST['cpassword']) ? $_POST['cpassword'] : ""; ?>">
                <?php echo form_error('cpassword', '<div class="text-danger">', '</div>'); ?>
            </div>
            <button type="submit" class="btn btn-success">Submit</button>
        </div>
    </div>
</div>

