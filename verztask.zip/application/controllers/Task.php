<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('tasks');
	}
	
	public function index()
	{
		$this->load->view('header', [
			'title' => 'Account Registration'
		]);
		$this->load->view('index');
		$this->load->view('footer');
	}

	public function account_registration_db() {
		$validation = [
			[
				'field' => 'fullname',
				'label' => 'Fullname',
				'rules' => 'required'
			],
			[
				'field' => 'email',
				'label' => 'Email',
				'rules' => 'required|valid_email'
			],
			[
				'field' => 'mobile',
				'label' => 'Mobile',
				'rules' => 'required|numeric|exact_length[10]'
			],
			[
				'field' => 'password',
				'label' => 'Password',
				'rules' => 'required'
			],
			[
				'field' => 'cpassword',
				'label' => 'Confirm Password',
				'rules' => 'required|matches[password]'
			]
		];

		$this->form_validation->set_rules($validation);

		if ($this->form_validation->run() == FALSE)
        {
                $this->load->view('header', [
					'title' => 'Account Registration'
				]);
				$this->load->view('index');
				$this->load->view('footer');
        }
        else
        {
                $config['upload_path']          = 'assets/images';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;
                $config['overwrite'] 			= FALSE;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('profile'))
                {
                        $error = array('error' => $this->upload->display_errors());

                       	$this->load->view('header', [
							'title' => 'Account Registration'
						]);
						$this->load->view('index', $error);
						$this->load->view('footer');
		                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());

                        $result = $this->tasks->account_registration_db($_POST, $data);
                        print_r($result);
                        /*if($result=='email_exist') {
                        	$email_error = "Email already exists.";
	                        $this->load->view('header', [
								'title' => 'Account Registration'
							]);
							$this->load->view('index', [
								'email_error' => $email_error
							]);
							$this->load->view('footer');
						}*/
                }
        }
	}

	public function login()
	{
		$this->load->view('header', [
			'title' => 'Login'
		]);
		$this->load->view('login');
		$this->load->view('footer');
	}

	public function login_db()
	{
		$validation = [
			[
				'field' => 'email',
				'label' => 'Email',
				'rules' => 'required|valid_email'
			],
			[
				'field' => 'password',
				'label' => 'Password',
				'rules' => 'required'
			]
		];

		$this->form_validation->set_rules($validation);

		if ($this->form_validation->run() == FALSE)
        {
                $this->load->view('header', [
					'title' => 'Login'
				]);
				$this->load->view('login');
				$this->load->view('footer');
        }
        else
        {
        	$result = $this->tasks->login_db($_POST);

        	//print_r($result);
            if($result=='invalid_credentials') {
            	$login_error = "Invalid Login Credentials.";
                $this->load->view('header', [
					'title' => 'Login'
				]);
				$this->load->view('login', [
					'login_error' => $login_error
				]);
				$this->load->view('footer');
			}
        }
		

	}

	public function dashboard() {
		$result = $this->tasks->get_data();
		$this->load->view('header', [
			'title' => 'Dashboard'
		]);
		$this->load->view('dashboard', [
			'user_data' => $result
		]);
		$this->load->view('footer');
	}
}
